<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET,POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Conecta a la base de datos  con usuario, contraseña y nombre de la BD
$servidor = "localhost"; $usuario = "root"; $contrasenia = ""; $nombreBaseDatos = "panel";
$conexionBD = new mysqli($servidor, $usuario, $contrasenia, $nombreBaseDatos);


// Consulta datos y recepciona una clave para consultar dichos datos con dicha clave
if (isset($_GET["consultar"])){
    $sqlProduuctos = mysqli_query($conexionBD,"SELECT * FROM productos WHERE idProducto=".$_GET["consultar"]);
    if(mysqli_num_rows($sqlProduuctos) > 0){
        $produuctos = mysqli_fetch_all($sqlProduuctos,MYSQLI_ASSOC);
        echo json_encode($produuctos);
        exit();
    }
    else{  echo json_encode(["success"=>0]); }
}
//borrar pero se le debe de enviar una clave ( para borrado )
if (isset($_GET["borrar"])){
    $sqlProduuctos = mysqli_query($conexionBD,"DELETE FROM productos WHERE idProducto=".$_GET["borrar"]);
    if($sqlProduuctos){
        echo json_encode(["success"=>1]);
        exit();
    }
    else{  echo json_encode(["success"=>0]); }
}
//Inserta un nuevo registro y recepciona en método post los datos de nombre y correo
if(isset($_GET["insertar"])){
    $data = json_decode(file_get_contents("php://input"));
    $nombre=$data->nombre;
    $precio=$data->precio;
        if(($nombre!="")&&($precio!="")){
            
    $sqlProduuctos = mysqli_query($conexionBD,"INSERT INTO productos(nombre, precio) VALUES('$nombre','$precio') ");
    echo json_encode(["success"=>1]);
        }
    exit();
}
// Actualiza datos pero recepciona datos de nombre, correo y una clave para realizar la actualización
if(isset($_GET["actualizar"])){
    
    $data = json_decode(file_get_contents("php://input"));

    $idProducto=(isset($data->idProducto))?$data->idProducto:$_GET["actualizar"];
    $nombre=$data->nombre;
    $precio=$data->precio;
    
    $sqlProduuctos = mysqli_query($conexionBD,"UPDATE productos SET nombre='$nombre',precio='$precio' WHERE idProducto='$idProducto'");
    echo json_encode(["success"=>1]);
    exit();
}
// Consulta todos los registros de la tabla empleados
$sqlProduuctos = mysqli_query($conexionBD,"SELECT * FROM productos ");
if(mysqli_num_rows($sqlProduuctos) > 0){
    $produuctos = mysqli_fetch_all($sqlProduuctos,MYSQLI_ASSOC);
    echo json_encode($produuctos);
}
else{ echo json_encode([["success"=>0]]); }


?>
