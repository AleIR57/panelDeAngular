<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET,POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Conecta a la base de datos  con usuario, contraseña y nombre de la BD
$servidor = "localhost"; $usuario = "root"; $contrasenia = ""; $nombreBaseDatos = "panel";
$conexionBD = new mysqli($servidor, $usuario, $contrasenia, $nombreBaseDatos);


// Consulta datos y recepciona una clave para consultar dichos datos con dicha clave
if (isset($_GET["consultar"])){
    $sqlRolees = mysqli_query($conexionBD,"SELECT * FROM rol WHERE idRol=".$_GET["consultar"]);
    if(mysqli_num_rows($sqlRolees) > 0){
        $rolees = mysqli_fetch_all($sqlRolees,MYSQLI_ASSOC);
        echo json_encode($rolees);
        exit();
    }
    else{  echo json_encode(["success"=>0]); }
}


?>
