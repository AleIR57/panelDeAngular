<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET,POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Conecta a la base de datos  con usuario, contraseña y nombre de la BD
$servidor = "localhost"; $usuario = "root"; $contrasenia = ""; $nombreBaseDatos = "panel";
$conexionBD = new mysqli($servidor, $usuario, $contrasenia, $nombreBaseDatos);


// Consulta datos y recepciona una clave para consultar dichos datos con dicha clave
if (isset($_GET["consultar"])){
    $sqlVendedorees = mysqli_query($conexionBD,"SELECT * FROM vendedores WHERE idVendedor=".$_GET["consultar"]);
    if(mysqli_num_rows($sqlVendedorees) > 0){
        $vendedorees = mysqli_fetch_all($sqlVendedorees,MYSQLI_ASSOC);
        echo json_encode($vendedorees);
        exit();
    }
    else{  echo json_encode(["success"=>0]); }
}
//borrar pero se le debe de enviar una clave ( para borrado )
if (isset($_GET["borrar"])){
    $sqlVendedorees = mysqli_query($conexionBD,"DELETE FROM vendedores WHERE idVendedor=".$_GET["borrar"]);
    if($sqlVendedorees){
        echo json_encode(["success"=>1]);
        exit();
    }
    else{  echo json_encode(["success"=>0]); }
}
//Inserta un nuevo registro y recepciona en método post los datos de nombre y correo
if(isset($_GET["insertar"])){
    $data = json_decode(file_get_contents("php://input"));
    $nombre=$data->nombre;
    $nombreUsuario=$data->nombreUsuario;
    $correo=$data->correo;
    $contrasena=$data->contrasena;
    $numeroTelefono=$data->numeroTelefono;
    $idRol=$data->idRol;
    $empresa=$data->empresa;
    $saldo=$data->saldo;
    $creditos=$data->creditos;
        if(($nombre!="")&&($nombreUsuario!="")&&($correo!="")&&($contrasena!="")&&($numeroTelefono!="")&&($idRol!="")&&($empresa!="")&&($saldo!="")&&($creditos!="")){
            
    $sqlClientees = mysqli_query($conexionBD,"INSERT INTO vendedores(nombre, nombreUsuario, correo, contrasena, numeroTelefono, idRol, empresa, saldo, creditos) VALUES('$nombre','$nombreUsuario','$correo','$contrasena','$numeroTelefono','$idRol','$empresa','$saldo','$creditos') ");
    echo json_encode(["success"=>1]);
        }
    exit();
}
// Actualiza datos pero recepciona datos de nombre, correo y una clave para realizar la actualización
if(isset($_GET["actualizar"])){
    
    $data = json_decode(file_get_contents("php://input"));

    $idVendedor=(isset($data->idVendedor))?$data->idVendedor:$_GET["actualizar"];
       $nombre=$data->nombre;
    $nombreUsuario=$data->nombreUsuario;
    $correo=$data->correo;
    $contrasena=$data->contrasena;
    $numeroTelefono=$data->numeroTelefono;
    $idRol=$data->idRol;
    $empresa=$data->empresa;
    $saldo=$data->saldo;
    $creditos=$data->creditos;
    
    $sqlVendedorees = mysqli_query($conexionBD,"UPDATE vendedores SET nombre='$nombre',nombreUsuario='$nombreUsuario',correo='$correo',contrasena='$contrasena',numeroTelefono='$numeroTelefono',idRol='$idRol',empresa='$empresa',saldo='$saldo',creditos='$creditos' WHERE idVendedor='$idVendedor'");
    echo json_encode(["success"=>1]);
    exit();
}
// Consulta todos los registros de la tabla empleados
$sqlVendedorees = mysqli_query($conexionBD,"SELECT * FROM vendedores ");
if(mysqli_num_rows($sqlVendedorees) > 0){
    $vendedorees = mysqli_fetch_all($sqlVendedorees,MYSQLI_ASSOC);
    echo json_encode($vendedorees);
}
else{ echo json_encode([["success"=>0]]); }


?>
