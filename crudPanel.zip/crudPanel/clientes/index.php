<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET,POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Conecta a la base de datos  con usuario, contraseña y nombre de la BD
$servidor = "localhost"; $usuario = "root"; $contrasenia = ""; $nombreBaseDatos = "panel";
$conexionBD = new mysqli($servidor, $usuario, $contrasenia, $nombreBaseDatos);


// Consulta datos y recepciona una clave para consultar dichos datos con dicha clave
if (isset($_GET["consultar"])){
    $sqlClientees = mysqli_query($conexionBD,"SELECT * FROM clientes WHERE idCliente=".$_GET["consultar"]);
    if(mysqli_num_rows($sqlClientees) > 0){
        $clientees = mysqli_fetch_all($sqlClientees,MYSQLI_ASSOC);
        echo json_encode($clientees);
        exit();
    }
    else{  echo json_encode(["success"=>0]); }
}
//borrar pero se le debe de enviar una clave ( para borrado )
if (isset($_GET["borrar"])){
    $sqlClientees = mysqli_query($conexionBD,"DELETE FROM clientes WHERE idCliente=".$_GET["borrar"]);
    if($sqlClientees){
        echo json_encode(["success"=>1]);
        exit();
    }
    else{  echo json_encode(["success"=>0]); }
}
//Inserta un nuevo registro y recepciona en método post los datos de nombre y correo
if(isset($_GET["insertar"])){
    $data = json_decode(file_get_contents("php://input"));
    $nombres=$data->nombres;
    $apellidos=$data->apellidos;
    $correo=$data->correo;
    $telefono=$data->telefono;
    $whatsapp=$data->whatsapp;
    $idVendedor=$data->idVendedor;
        if(($correo!="")&&($nombres!="")&&($apellidos!="")&&($correo!="")&&($telefono!="")&&($whatsapp!="")&&($idVendedor!="")){
            
    $sqlClientees = mysqli_query($conexionBD,"INSERT INTO clientes(nombres, apellidos, correo, telefono, whatsapp, idVendedor) VALUES('$nombres','$apellidos','$correo','$telefono','$whatsapp','$idVendedor') ");
    echo json_encode(["success"=>1]);
        }
    exit();
}
// Actualiza datos pero recepciona datos de nombre, correo y una clave para realizar la actualización
if(isset($_GET["actualizar"])){
    
    $data = json_decode(file_get_contents("php://input"));

    $idCliente=(isset($data->idCliente))?$data->idCliente:$_GET["actualizar"];
    $nombres=$data->nombres;
    $apellidos=$data->apellidos;
    $correo=$data->correo;
    $telefono=$data->telefono;
    $whatsapp=$data->whatsapp;
    $idVendedor=$data->idVendedor;
    
    $sqlClientees = mysqli_query($conexionBD,"UPDATE clientes SET nombres='$nombres',apellidos='$apellidos',correo='$correo',telefono='$telefono',whatsapp='$whatsapp',idVendedor='$idVendedor' WHERE idCliente='$idCliente'");
    echo json_encode(["success"=>1]);
    exit();
}
// Consulta todos los registros de la tabla empleados
$sqlClientees = mysqli_query($conexionBD,"SELECT * FROM clientes ");
if(mysqli_num_rows($sqlClientees) > 0){
    $clientees = mysqli_fetch_all($sqlClientees,MYSQLI_ASSOC);
    echo json_encode($clientees);
}
else{ echo json_encode([["success"=>0]]); }


?>
