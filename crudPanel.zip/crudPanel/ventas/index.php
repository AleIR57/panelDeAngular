<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET,POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Conecta a la base de datos  con usuario, contraseña y nombre de la BD
$servidor = "localhost"; $usuario = "root"; $contrasenia = ""; $nombreBaseDatos = "panel";
$conexionBD = new mysqli($servidor, $usuario, $contrasenia, $nombreBaseDatos);


// Consulta datos y recepciona una clave para consultar dichos datos con dicha clave
if (isset($_GET["consultar"])){
    $sqlVentaas = mysqli_query($conexionBD,"SELECT * FROM ventas WHERE idVenta=".$_GET["consultar"]);
    if(mysqli_num_rows($sqlVentaas) > 0){
        $ventaas = mysqli_fetch_all($sqlVentaas,MYSQLI_ASSOC);
        echo json_encode($ventaas);
        exit();
    }
    else{  echo json_encode(["success"=>0]); }
}

if (isset($_GET["consultar2"])){
    $sqlVentaas2 = mysqli_query($conexionBD,"SELECT cliente.nombres, cliente.apellidos FROM ventas, clientes WHERE ventas.idCliente = clientes.idCliente and idVenta = ".$_GET["consultar2"].";");
if(mysqli_num_rows($sqlVentaas2) > 0){
    $ventaas2 = mysqli_fetch_all($sqlVentaas2,MYSQLI_ASSOC);
    echo json_encode($ventaas2);
}
else{ echo json_encode([["success"=>0]]); }
}

//borrar pero se le debe de enviar una clave ( para borrado )
if (isset($_GET["borrar"])){
    $sqlVentaas = mysqli_query($conexionBD,"DELETE FROM ventas WHERE idVenta=".$_GET["borrar"]);
    if($sqlVentaas){
        echo json_encode(["success"=>1]);
        exit();
    }
    else{  echo json_encode(["success"=>0]); }
}
//Inserta un nuevo registro y recepciona en método post los datos de nombre y correo
if(isset($_GET["insertar"])){
    $data = json_decode(file_get_contents("php://input"));
    $idProducto=$data->idProducto;
    $idCliente=$data->idCliente;
    $idCuenta = $data->idCuenta;
    $cantidad=$data->cantidad;
    $precioTotal=$data->precioTotal;
    $metodoPago=$data->metodoPago;
    $fecha=$data->fecha;
    $observacion=$data->observacion;
    $estado=$data->estado;
        if(($idProducto!="")&&($idCliente!="")&&($idCuenta!="")&&($cantidad!="")&&($precioTotal!="")&&($metodoPago!="")&&($fecha!="")&&($observacion!="")&&($estado!="")){
            
    $sqlVentaas = mysqli_query($conexionBD,"INSERT INTO ventas(idProducto, idCliente, idCuenta, cantidad, precioTotal, metodoPago, fecha, observacion, estado) VALUES('$idProducto','$idCliente','$idCuenta','$cantidad','$precioTotal','$metodoPago','$fecha','$observacion','$estado') ");
    echo json_encode(["success"=>1]);
        }
    exit();
}
// Actualiza datos pero recepciona datos de nombre, correo y una clave para realizar la actualización
if(isset($_GET["actualizar"])){
    
    $data = json_decode(file_get_contents("php://input"));

    $idVenta=(isset($data->idVenta))?$data->idVenta:$_GET["actualizar"];
    $idProducto=$data->idProducto;
    $idCliente=$data->idCliente;
    $idCuenta = $data->idCuenta;
    $cantidad=$data->cantidad;
    $precioTotal=$data->precioTotal;
    $metodoPago=$data->metodoPago;
    $fecha=$data->fecha;
    $observacion=$data->observacion;
    $estado=$data->estado;
    
    $sqlVentaas = mysqli_query($conexionBD,"UPDATE ventas SET idProducto='$idProducto',idCliente='$idCliente',idCuenta='$idCuenta',cantidad='$cantidad',precioTotal='$precioTotal',metodoPago='$metodoPago',fecha='$fecha',observacion='$observacion',estado='$estado' WHERE idVenta='$idVenta'");
    echo json_encode(["success"=>1]);
    exit();
}
// Consulta todos los registros de la tabla empleados
$sqlVentaas = mysqli_query($conexionBD,"SELECT * FROM ventas ");
if(mysqli_num_rows($sqlVentaas) > 0){
    $ventaas = mysqli_fetch_all($sqlVentaas,MYSQLI_ASSOC);
    echo json_encode($ventaas);
}
else{ echo json_encode([["success"=>0]]); }


?>
